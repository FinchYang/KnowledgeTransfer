﻿/**
 * 知识文档相关操作：获取类别树，获取条件列表等
 */
var knowDocOps = knowDocOps || {};
(function (k) {
	var docClassGroups;
	var docClasses;
	
	/**
	 * function：搜索文档
	 * discipines：专业
	 * skills：技术
	 * projs：项目
	 * athers：其他
	 * return: 文档视图
	 */
	k.searchDocs = function (mfVault, classId, docType, discipines, skills, projs, athers, fileName) {

		var oSearchConditions = this.cSearchConditions(mfVault, classId, docType, discipines, skills, projs, athers, fileName);

		var view = MF.ObjectOps.getTempSearchView(mfVault, "", 0, classId, oSearchConditions);

        var viewPath = MF.ObjectOps.getSearchViewLoc(mfVault, view);
		var arry = viewPath.split("\\");
		var tempView = "";
		for (var i = 2; i < arry.length - 1; i++) {
			tempView += arry[i] + "\\";
		}

        var viewId = view.ID;

		var tempObj = {
			path: tempView,
			id: viewId
		};

		return tempObj;
	};
	
	/**
	 * function：创建搜索条件对象
	 */
	k.cSearchConditions = function (mfVault, classId, docType, discipines, skills, projs, athers, fileName) {
		//var classId = MF.alias.classType(mfVault, md.bimModelDoc.classAlias);
        var sConditons = MFiles.CreateInstance("SearchConditions");

		if (classId || classId === 0) {
			//类别
			var conditionClass = MFiles.CreateInstance("SearchCondition");//创建搜索条件
			conditionClass.ConditionType = MFConditionTypeEqual;//搜索操作
			conditionClass.Expression.DataPropertyValuePropertyDef = MFBuiltInPropertyDefClass;//操作属性
			conditionClass.TypedValue.SetValue(MFDatatypeLookup, classId);//属性值
			sConditons.Add(-1, conditionClass);
		} 
		 
		//文件名、文件类型搜索
		var fileFullName = this._searchText(docType, fileName)
		if (fileFullName) { 
			var format = fileFullName + "*"; 
			var namePattern = new MFiles.SearchCondition();
			namePattern.ConditionType = MFConditionTypeMatchesWildcardPattern;
			namePattern.Expression.SetFileValueExpression(MFFileValueTypeFileName);
			namePattern.TypedValue.SetValue(MFDatatypeText, format);
			sConditons.Add(-1, namePattern);
		} 
		
		//顺序为 专业 技术 项目 其他
		var conditonValues = [discipines, skills, projs, athers];
		var propIds = [
			MF.alias.propertyDef(mfVault, md.documents.ClassList.Awards.Properties.Specialty),
			MF.alias.propertyDef(mfVault, md.documents.ClassList.Awards.Properties.Technology),
			MF.alias.propertyDef(mfVault, md.documents.ClassList.Awards.Properties.Project),
			MF.alias.propertyDef(mfVault, md.documents.ClassList.Awards.Properties.Other)
		];
		for (var index = 0; index < conditonValues.length; index++) {
			if (conditonValues[index]) {
				this._conditon(sConditons, propIds[index], conditonValues[index]);
			}
		}
        return sConditons;
	};

    k._searchText = function (docType, fileName) { 
		if (fileName || docType[0] && docType[0] != 0) { 
			var typeName = '';
			if (docType && docType.length) {
				//文档类型
				var types = k.getDocTypeList();
				for (var i = 0; i < types.length; i++) {
					if (types[i].Id == docType[0]) {
						typeName = types[i].Name;
						break;
					}
				}
				if (typeName) {
					typeName = typeName.split("(")[0];
					//匹配通配符，在MFiles中只支持2中匹配符：'*'(0个或多个字符)和'?'(0个或1个字符)
				} 
			}
			if (!fileName) fileName = '';
			if (fileName && fileName[fileName.length - 1] != '*' || fileName == '') {
				fileName += "*";
			}
			var fileFullName = fileName + typeName; 
			return fileFullName;
		}
		return undefined;
	}

	k._conditon = function (sConditons, PropertyDef, Values) {

		var newValues = this._newMultiSelectLookupProperty(Values);
		if (newValues) {
			var tempConditon = MFiles.CreateInstance("SearchCondition");//创建搜索条件
			tempConditon.ConditionType = MFConditionTypeEqual;//搜索操作
			tempConditon.Expression.DataPropertyValuePropertyDef = PropertyDef; //操作属性
			tempConditon.TypedValue.SetValue(MFDatatypeMultiSelectLookup, newValues);//属性值
			sConditons.Add(-1, tempConditon);
		}
	}

	k._newMultiSelectLookupProperty = function (arryValue) {
		///<summary>新建多选属性</summary>
		///<param name="propDefId" type="long">PropertyDef</param>
		///<param name="arryValue" type="int[]">整型数组值</param>
		var value = new MFiles.Lookups();
		for (var i = 0; i < arryValue.length; i++) {
			var item = new MFiles.Lookup();
			item.Item = arryValue[i];
			value.Add(-1, item);
		}
		return value = value.Count === 0 ? null : value;
	};
	
	/**
	 * 获取类别目录树
	 */
	k.getClassesTree = function (mfVault) {
		if (!docClassGroups) {
			docClassGroups = mfVault.ClassGroupOperations.GetClassGroups(0);
		}
		if (!docClasses) {
			docClasses = [];
			var classList = md.documents.ClassList;
			for (var k in classList) {
				var classId = MF.alias.classType(mfVault, classList[k].Alias);
				var objClass = mfVault.ClassOperations.GetObjectClass(classId);
				docClasses.push({
					Id: objClass.ID,
					Name: objClass.Name,
					GroupName: ""
				});
			}
		}

		var classesTree = [];

		for (var i = 1; i <= docClassGroups.Count; i++) {
			var item = docClassGroups.Item(i);
			var classGroup = {};
			classGroup.Id = item.ID;
			classGroup.Name = item.Name;
			classGroup.Classes = [];

			var classIds = item.Members;
			for (var j = 0; j < docClasses.length; j++) {
				if (classIds.IndexOf(docClasses[j].Id) > -1) {
					if (docClasses[j].GroupName) {
						docClasses[j].GroupName += ";" + item.Name;
					} else {
						docClasses[j].GroupName = item.Name;
					}

					classGroup.Classes.push({
						Id: docClasses[j].Id,
						Name: docClasses[j].Name
					});
				}
			}
			classesTree.push(classGroup);
		}

		var classGroup0 = {
			Id: -1,
			Name: "未分组",
			Classes: []
		}
		for (var m = 0; m < docClasses.length; m++) {
			if (!docClasses[m].GroupName) {
				classGroup0.Classes.push({
					Id: docClasses[m].Id,
					Name: docClasses[m].Name
				});
			}
		}
		classesTree.push(classGroup0);
		return classesTree;
	};
	/**
	 * 获取文档类型列表
	 */
	k.getDocTypeList = function (mfVault) {
		var types = [];
		types.push({ Id: 0, Name: ".*(全部类型)" });
		types.push({ Id: 1, Name: ".doc(.docx)" });
		types.push({ Id: 2, Name: ".pdf" });
		types.push({ Id: 3, Name: ".xls(.xlsx)" });
		types.push({ Id: 4, Name: ".rtf" });
		types.push({ Id: 5, Name: ".ppt(.pptx)" });
		types.push({ Id: 6, Name: ".dwg" });

		return types;
	};
	
	/**
	 * 获取专业列表
	 */
	k.getDisciplineList = function (mfVault) {
		var vlId = MF.alias.valueList(mfVault, md.valueList.Specialty);
		return k._getValueListItems(mfVault, vlId);
	};
	/**
	 * 获取技术列表
	 */
	k.getSkillList = function (mfVault) {
		var vlId = MF.alias.valueList(mfVault, md.valueList.Technology);
		return k._getValueListItems(mfVault, vlId);
	};
	/**
	 * 获取项目列表
	 */
	k.getProjectList = function (mfVault) {

		var vlId = MF.alias.valueList(mfVault, md.valueList.Project);
		return k._getValueListItems(mfVault, vlId);
	};
	/**
	 * 获取其他项列表
	 */
	k.getOtherItemList = function (mfVault) {

		var vlId = MF.alias.valueList(mfVault, md.valueList.Other);
		return k._getValueListItems(mfVault, vlId);
	};

	k._getValueListItems = function (mfVault, valueListId) {
		var items = [];
		var values = mfVault.ValueListItemOperations.GetValueListItems(valueListId);
		for (var i = 1; i <= values.Count; i++) {
			items.push({
				Id: values.Item(i).ID,
				Name: values.Item(i).Name
			});
		}
		return items;
	};
})(knowDocOps);
