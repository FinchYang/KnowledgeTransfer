﻿/*******************
 * shellUI模块入口
 **************************/	
 
"use strict";

function OnNewShellUI(shellUI) {
    shellUI.Events.Register(MFiles.Event.NewShellFrame, newShellFrameHandler);
}


function newShellFrameHandler(shellFrame) {
    shellFrame.Events.Register(MFiles.Event.Started, getShellFrameStartedHandler(shellFrame));
}

/**
 * shellFrame对象启动的函数入口
 * @param {string} shellFrame shellUI的入口实例
 */
function getShellFrameStartedHandler(shellFrame) {
     
    
    // Return the handler function for Started event.
    return function () {       
        var vault = shellFrame.ShellUI.Vault;
        //主目录
        /*if (shellFrame.CurrentPath === "") {
            shellFrame.CurrentPath = "按类别";
	    }*/

	    if (shellFrame.CurrentPath === '') {
            shellFrame.RightPane.Visible = false;
            var customData = {Vault:vault};
            shellFrame.ShowDashboard("doccategory", customData);
	    }
    };
}

function test(shellFrame){
    var vault = shellFrame.ShellUI.Vault;
    var doms = knowDocOps.getClassesTree(vault);

    var info ="";
    for(var i = 0; i < doms.length; i++){
        info += doms[i].Name+":";
        for(var j=0; j < doms[i].Classes.length; j++){
            info += doms[i].Classes[j].Name+";";
        }
        info += "\n";
    }
    //shellFrame.ShellUI.ShowMessage(info);
    
    shellFrame.ShellUI.ShowMessage(knowDocOps.getDisciplineList(vault).length);
}

